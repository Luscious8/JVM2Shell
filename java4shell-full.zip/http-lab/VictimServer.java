import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class VictimServer {
    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(
            new InetSocketAddress("0.0.0.0", 8080), 0
        );

        server.createContext("/decode", exchange -> {
            if (!exchange.getRequestMethod().equals("POST")) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }

            byte[] body = exchange.getRequestBody().readNBytes(1024);

            try {
                String input = new String(body, StandardCharsets.UTF_8);
                byte[] decoded = Base64.getDecoder().decode(input);

                String response = "DECODE_SUCCESS: " + decoded.length + " bytes";
                byte[] output = response.getBytes(StandardCharsets.UTF_8);

                exchange.sendResponseHeaders(200, output.length);
                exchange.getResponseBody().write(output);

                System.out.println("[+] Base64 decoded: " + decoded.length + " bytes");
            } catch (IllegalArgumentException e) {
                byte[] output = "INVALID_BASE64".getBytes(StandardCharsets.UTF_8);
                exchange.sendResponseHeaders(400, output.length);
                exchange.getResponseBody().write(output);

                System.out.println("[!] Invalid Base64 received");
            } finally {
                exchange.close();
            }
        });

        System.out.println("[+] Victim listening on http://0.0.0.0:8080");
        server.start();
    }
}
