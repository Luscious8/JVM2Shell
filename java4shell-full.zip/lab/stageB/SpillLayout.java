import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import sun.misc.Unsafe;

public final class SpillLayout {
    static Unsafe U;
    static volatile byte[] out, victim;
    static volatile Object[] holder;
    static long mark, klass;
    static int lenBefore;

    public static void main(String[] a) throws Exception {
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);

        Base64.Decoder d = Base64.getDecoder();
        byte[] valid = "A".repeat(64).getBytes(StandardCharsets.US_ASCII);
        byte[] bad   = ("A".repeat(64) + "=").getBytes(StandardCharsets.US_ASCII);

        alloc();
        for (int i = 0; i < 200_000; i++) d.decode(valid, out);

        int o1 = U.getInt(holder, 16L);
        int o2 = U.getInt(holder, 20L);
        System.out.printf("out@%08x victim@%08x delta=%d%n", o1, o2, o2 - o1);

        mark = U.getLong(victim, 0L);
        klass = U.getInt(victim, 8L) & 0xffffffffL;
        lenBefore = U.getInt(victim, 12L);
        System.out.printf("before: mark=%016x klass=%08x len=%d%n", mark, klass, lenBefore);

        boolean rejected = false;
        try { d.decode(bad, out); } catch (IllegalArgumentException e) { rejected = true; }

        int lenAfter = U.getInt(victim, 12L);
        long markAfter = U.getLong(victim, 0L);
        int klassAfter = U.getInt(victim, 8L);

        System.out.printf("rejected=%s%n", rejected);
        System.out.printf("after : mark=%016x klass=%08x len=%d%n", markAfter, klassAfter & 0xffffffffL, lenAfter);
        System.out.printf("VERDICT len_changed=%s header_clobbered=%s%n",
                lenAfter != lenBefore,
                markAfter != mark || (klassAfter & 0xffffffffL) != klass);

        StringBuilder sb = new StringBuilder();
        for (int off = 16 + 24; off < 16 + 40; off++) sb.append(String.format("%02x", U.getByte(victim, (long) off) & 0xff));
        System.out.println("victim[24..39]=" + sb);

        U.putLong(victim, 0L, mark);
        U.putInt(victim, 8L, (int) klass);
        U.putInt(victim, 12L, lenBefore);
        System.out.println("repaired");
    }

    static void alloc() {
        out = new byte[50];
        victim = new byte[64];
        holder = new Object[]{out, victim};
    }
}
