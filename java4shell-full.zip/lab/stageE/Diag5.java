import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import sun.misc.Unsafe;

public final class Diag5 {
    static Unsafe U;
    static volatile long sink;
    static final byte[] PAT = {(byte) 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11};

    public static void main(String[] a) throws Exception {
        String mode = a.length > 0 ? a[0] : "pro";
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);

        List<String> maps = Files.readAllLines(Path.of("/proc/self/maps"));
        long[] best = null;
        for (String l : maps) {
            if (!l.contains("rwx")) continue;
            String[] r = l.split("\\s+")[0].split("-");
            long s = Long.parseUnsignedLong(r[0], 16), e = Long.parseUnsignedLong(r[1], 16);
            if (best == null || e - s > best[1] - best[0]) best = new long[]{s, e};
        }

        for (int i = 0; i < 300_000; i++) sink += probe(i);

        long hit = -1;
        outer:
        for (long p = best[0]; p < best[1] - 8; p++) {
            if (U.getByte(p) != PAT[0]) continue;
            for (int i = 1; i < 8; i++) if (U.getByte(p + i) != PAT[i]) continue outer;
            hit = p; break;
        }

        long pro = -1;
        for (long p = hit - 512; p < hit; p++)
            if ((U.getByte(p) & 0xff) == 0x55 && (U.getByte(p + 1) & 0xff) == 0x48
                    && (U.getByte(p + 2) & 0xff) == 0x83 && (U.getByte(p + 3) & 0xff) == 0xec) pro = p;

        long site;
        switch (mode) {
            case "e9":  site = pro - 7; break;
            case "hit": site = hit; break;
            default:    site = pro; break;
        }

        System.out.printf("mode=%s hit=%x pro=%x site=%x%n", mode, hit, pro, site);
        System.out.println("probe before=" + Long.toHexString(probe(1)));
        U.putByte(site, (byte) 0xCC);
        System.out.println("int3 written, calling probe...");
        System.out.println("probe after=" + Long.toHexString(probe(1)));
        System.out.println("STILL ALIVE -> site not executed");
    }

    static long probe(long x) { return x ^ 0x1122334455667788L; }
}
