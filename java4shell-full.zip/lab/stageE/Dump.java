import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import sun.misc.Unsafe;

public final class Dump {
    static Unsafe U;
    static volatile long sink;
    static final byte[] PAT = {(byte) 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11};

    public static void main(String[] a) throws Exception {
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);

        List<String> maps = Files.readAllLines(Path.of("/proc/self/maps"));
        long[] best = null;
        for (String l : maps) {
            if (!l.contains("rwx")) continue;
            String[] r = l.split("\\s+")[0].split("-");
            long s = Long.parseUnsignedLong(r[0], 16), e = Long.parseUnsignedLong(r[1], 16);
            if (best == null || e - s > best[1] - best[0]) best = new long[]{s, e};
        }
        System.out.printf("rwx %016x-%016x%n", best[0], best[1]);

        for (int i = 0; i < 300_000; i++) sink += probe(i);

        long hit = -1;
        outer:
        for (long p = best[0]; p < best[1] - 8; p++) {
            if (U.getByte(p) != PAT[0]) continue;
            for (int i = 1; i < 8; i++) if (U.getByte(p + i) != PAT[i]) continue outer;
            hit = p; break;
        }
        System.out.println("hit=" + Long.toHexString(hit));

        long start = hit - 320;
        for (long p = start; p < hit + 40; p += 16) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 16; i++) sb.append(String.format("%02x ", U.getByte(p + i) & 0xff));
            System.out.printf("%+5d %016x  %s%n", p - hit, p, sb);
        }

        System.out.println("--- call-site candidates (any REX.W movabs) ---");
        int c = 0;
        for (long p = best[0]; p < best[1] - 10; p++) {
            int b0 = U.getByte(p) & 0xff, b1 = U.getByte(p + 1) & 0xff;
            if ((b0 == 0x48 || b0 == 0x49) && b1 >= 0xb8 && b1 <= 0xbf) {
                long t = U.getLong(p + 2);
                if (t >= hit - 8192 && t <= hit + 64) {
                    System.out.printf("at %016x -> %016x (delta %d) reg=%d%n", p, t, t - hit, b1 - 0xb8);
                    c++;
                }
            }
        }
        System.out.println("candidates=" + c);
    }

    static long probe(long x) { return x ^ 0x1122334455667788L; }
}
