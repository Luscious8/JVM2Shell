import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import sun.misc.Unsafe;

public final class Live {
    static Unsafe U;
    static volatile long sink;
    static final byte[] PAT = {(byte) 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11};

    public static void main(String[] a) throws Exception {
        int want = Integer.parseInt(a[0]);
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);

        for (int i = 0; i < 300_000; i++) sink += probe(i);

        List<long[]> regs = new ArrayList<>();
        for (String l : Files.readAllLines(Path.of("/proc/self/maps"))) {
            if (!l.contains("rwx")) continue;
            String[] p = l.split("\\s+")[0].split("-");
            regs.add(new long[]{Long.parseUnsignedLong(p[0], 16), Long.parseUnsignedLong(p[1], 16)});
        }
        long[] R = regs.get(want - 1);

        long hit = -1;
        outer:
        for (long p = R[0]; p < R[1] - 8; p++) {
            if (U.getByte(p) != PAT[0]) continue;
            for (int i = 1; i < 8; i++) if (U.getByte(p + i) != PAT[i]) continue outer;
            hit = p; break;
        }
        System.out.println("region " + want + " hit=" + Long.toHexString(hit));

        for (long p = hit - 96; p < hit + 32; p += 16) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 16; i++) sb.append(String.format("%02x ", U.getByte(p + i) & 0xff));
            System.out.printf("%+5d %s%n", p - hit, sb);
        }

        U.putByte(hit, (byte) 0xCC);
        System.out.println("int3 at hit, calling probe...");
        System.out.println("ALIVE " + Long.toHexString(probe(1)));
    }

    static long probe(long x) { return x ^ 0x1122334455667788L; }
}
