import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import sun.misc.Unsafe;

public final class Pick {
    static Unsafe U;
    static volatile long sink;
    static final byte[] PAT = {(byte) 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11};

    public static void main(String[] a) throws Exception {
        int want = Integer.parseInt(a[0]);
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);

        for (int i = 0; i < 300_000; i++) sink += probe(i);

        List<long[]> regs = new ArrayList<>();
        for (String l : Files.readAllLines(Path.of("/proc/self/maps"))) {
            if (!l.contains("rwx")) continue;
            String[] p = l.split("\\s+")[0].split("-");
            regs.add(new long[]{Long.parseUnsignedLong(p[0], 16), Long.parseUnsignedLong(p[1], 16)});
        }
        long[] R = regs.get(want - 1);
        System.out.printf("region %d %016x-%016x%n", want, R[0], R[1]);

        long hit = -1;
        outer:
        for (long p = R[0]; p < R[1] - 8; p++) {
            if (U.getByte(p) != PAT[0]) continue;
            for (int i = 1; i < 8; i++) if (U.getByte(p + i) != PAT[i]) continue outer;
            hit = p; break;
        }
        System.out.println("hit=" + Long.toHexString(hit));

        long pro = -1;
        for (long p = hit - 512; p < hit; p++)
            if ((U.getByte(p) & 0xff) == 0x55 && (U.getByte(p + 1) & 0xff) == 0x48
                    && (U.getByte(p + 2) & 0xff) == 0x83 && (U.getByte(p + 3) & 0xff) == 0xec) pro = p;

        System.out.println("pro=" + Long.toHexString(pro) + " delta=" + (hit - pro));
        StringBuilder c = new StringBuilder();
        for (long p = pro - 12; p < pro + 16; p++) c.append(String.format("%02x", U.getByte(p) & 0xff));
        System.out.println("ctx: " + c + "  <pro at 12>");

        System.out.println("before=" + Long.toHexString(probe(1)));
        U.putByte(pro, (byte) 0xCC);
        System.out.println("int3 at pro");
        System.out.println("after=" + Long.toHexString(probe(1)));
        System.out.println("ALIVE");
    }

    static long probe(long x) { return x ^ 0x1122334455667788L; }
}
