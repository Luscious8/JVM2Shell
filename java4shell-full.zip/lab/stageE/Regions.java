import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import sun.misc.Unsafe;

public final class Regions {
    static Unsafe U;
    static volatile long sink;
    static final byte[] PAT = {(byte) 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11};

    public static void main(String[] a) throws Exception {
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        U = (Unsafe) f.get(null);

        for (int i = 0; i < 300_000; i++) sink += probe(i);

        List<String> maps = Files.readAllLines(Path.of("/proc/self/maps"));
        int r = 0;
        for (String l : maps) {
            if (!l.contains("rwx")) continue;
            r++;
            String[] p = l.split("\\s+")[0].split("-");
            long s = Long.parseUnsignedLong(p[0], 16), e = Long.parseUnsignedLong(p[1], 16);
            int hits = 0;
            outer:
            for (long q = s; q < e - 8; q++) {
                if (U.getByte(q) != PAT[0]) continue;
                for (int i = 1; i < 8; i++) if (U.getByte(q + i) != PAT[i]) continue outer;
                hits++;
            }
            System.out.printf("region %d  %016x-%016x size=%d hits=%d%n", r, s, e, e - s, hits);
        }
        System.out.println("total rwx regions=" + r);
        System.out.println("probe(1)=" + Long.toHexString(probe(1)));
    }

    static long probe(long x) { return x ^ 0x1122334455667788L; }
}
